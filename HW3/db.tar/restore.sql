--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.14
-- Dumped by pg_dump version 10.6 (Ubuntu 10.6-0ubuntu0.18.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.ticket DROP CONSTRAINT ticket_passenger_id_fkey;
ALTER TABLE ONLY public.ticket DROP CONSTRAINT ticket_flight_id_fkey;
ALTER TABLE ONLY public.state DROP CONSTRAINT state_country_id_fkey;
ALTER TABLE ONLY public.price_capacity DROP CONSTRAINT price_capacity_flight_id_fkey;
ALTER TABLE ONLY public.flight DROP CONSTRAINT flight_start_airport_id_fkey;
ALTER TABLE ONLY public.flight_history DROP CONSTRAINT flight_history_start_airport_id_fkey;
ALTER TABLE ONLY public.flight_history DROP CONSTRAINT flight_history_end_airport_id_fkey;
ALTER TABLE ONLY public.flight_history DROP CONSTRAINT flight_history_airline_id_fkey;
ALTER TABLE ONLY public.flight DROP CONSTRAINT flight_end_airport_id_fkey;
ALTER TABLE ONLY public.flight DROP CONSTRAINT flight_airline_id_fkey;
ALTER TABLE ONLY public.city DROP CONSTRAINT city_state_id_fkey;
ALTER TABLE ONLY public.backup_flight DROP CONSTRAINT backup_flight_start_airport_id_fkey;
ALTER TABLE ONLY public.backup_flight DROP CONSTRAINT backup_flight_end_airport_id_fkey;
ALTER TABLE ONLY public.backup_flight DROP CONSTRAINT backup_flight_airline_id_fkey;
ALTER TABLE ONLY public.airport DROP CONSTRAINT airport_city_id_fkey;
DROP TRIGGER update_flight_trigger ON public.price_capacity;
DROP TRIGGER backup_flight_trigger ON public.flight;
ALTER TABLE ONLY public.ticket DROP CONSTRAINT ticket_pkey;
ALTER TABLE ONLY public.state DROP CONSTRAINT state_pkey;
ALTER TABLE ONLY public.price_capacity DROP CONSTRAINT price_capacity_pkey;
ALTER TABLE ONLY public.passenger DROP CONSTRAINT passenger_pkey;
ALTER TABLE ONLY public.flight DROP CONSTRAINT flight_pkey;
ALTER TABLE ONLY public.flight_history DROP CONSTRAINT flight_history_pkey;
ALTER TABLE ONLY public.country DROP CONSTRAINT country_pkey;
ALTER TABLE ONLY public.city DROP CONSTRAINT city_pkey;
ALTER TABLE ONLY public.backup_flight DROP CONSTRAINT backup_flight_pkey;
ALTER TABLE ONLY public.airport DROP CONSTRAINT airport_pkey;
ALTER TABLE ONLY public.airline DROP CONSTRAINT airline_pkey;
DROP TABLE public.ticket;
DROP TABLE public.passenger;
DROP VIEW public.org_airport;
DROP VIEW public.inter_state_flight_count;
DROP TABLE public.state;
DROP TABLE public.flight_history;
DROP TABLE public.country;
DROP VIEW public.conflict_price;
DROP VIEW public.last_price_capacity;
DROP TABLE public.price_capacity;
DROP TABLE public.flight;
DROP TABLE public.city;
DROP TABLE public.backup_flight;
DROP TABLE public.airport;
DROP TABLE public.airline;
DROP FUNCTION public.update_flight_price();
DROP FUNCTION public.remove_flight();
DROP FUNCTION public.log_last_flight();
DROP FUNCTION public.check_flight_is_done(integer);
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: check_flight_is_done(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.check_flight_is_done(integer) RETURNS boolean
    LANGUAGE sql
    AS $_$
    select CAST(flight.start_date + flight.start_hour AS timestamp) < now() from flight where flight.id = $1
$_$;


ALTER FUNCTION public.check_flight_is_done(integer) OWNER TO postgres;

--
-- Name: log_last_flight(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.log_last_flight() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NEW <> OLD THEN
 INSERT INTO backup_flight
 VALUES(OLD.id,OLD.start_date, OLD.start_airport_id, OLD.end_airport_id, OLD.start_hour, OLD.airline_id, OLD.flight_number, OLD.last_price, OLD.last_capacity ,now());
 END IF;
 
 RETURN NEW;
END;
$$;


ALTER FUNCTION public.log_last_flight() OWNER TO postgres;

--
-- Name: remove_flight(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.remove_flight() RETURNS void
    LANGUAGE plpgsql
    AS $$
    BEGIN
    insert into flight_history
        select id,start_date,start_airport_id,end_airport_id,start_hour,airline_id,flight_number from flight where check_flight_is_done(flight.id) = true;
        
    delete from price_capacity where check_flight_is_done(price_capacity.flight_id) = true; 
    delete from flight where check_flight_is_done(flight.id) = true;
    
    END;
$$;


ALTER FUNCTION public.remove_flight() OWNER TO postgres;

--
-- Name: update_flight_price(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_flight_price() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 
 UPDATE flight set
    last_price = NEW.price,
    last_capacity = NEW.capacity
 where id = NEW.flight_id ;
 RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_flight_price() OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: airline; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.airline (
    id character varying(2) NOT NULL,
    name character varying(100) NOT NULL
);


ALTER TABLE public.airline OWNER TO postgres;

--
-- Name: airport; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.airport (
    id character varying(3) NOT NULL,
    name character varying(100) NOT NULL,
    city_id integer,
    lat double precision,
    lan double precision
);


ALTER TABLE public.airport OWNER TO postgres;

--
-- Name: backup_flight; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.backup_flight (
    id integer NOT NULL,
    start_date date NOT NULL,
    start_airport_id character varying(3) NOT NULL,
    end_airport_id character varying(3) NOT NULL,
    start_hour time without time zone,
    airline_id character varying(2) NOT NULL,
    flight_number integer,
    last_price integer,
    last_capacity integer,
    modified timestamp without time zone NOT NULL,
    CONSTRAINT backup_flight_last_capacity_check CHECK ((last_capacity > 0)),
    CONSTRAINT backup_flight_last_price_check CHECK ((last_price > 0))
);


ALTER TABLE public.backup_flight OWNER TO postgres;

--
-- Name: city; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.city (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    state_id integer
);


ALTER TABLE public.city OWNER TO postgres;

--
-- Name: flight; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.flight (
    id integer NOT NULL,
    start_date date NOT NULL,
    start_airport_id character varying(3) NOT NULL,
    end_airport_id character varying(3) NOT NULL,
    start_hour time without time zone,
    airline_id character varying(2) NOT NULL,
    flight_number integer,
    last_price integer,
    last_capacity integer,
    CONSTRAINT flight_last_capacity_check CHECK ((last_capacity > 0)),
    CONSTRAINT flight_last_price_check CHECK ((last_price > 0))
);


ALTER TABLE public.flight OWNER TO postgres;

--
-- Name: price_capacity; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.price_capacity (
    flight_id integer NOT NULL,
    date timestamp without time zone NOT NULL,
    price integer NOT NULL,
    capacity integer NOT NULL,
    channel character varying(100),
    CONSTRAINT price_capacity_capacity_check CHECK ((capacity > 0)),
    CONSTRAINT price_capacity_channel_check CHECK (((channel)::text = ANY ((ARRAY['web service'::character varying, 'airline system'::character varying, 'phone'::character varying])::text[]))),
    CONSTRAINT price_capacity_price_check CHECK ((price > 0))
);


ALTER TABLE public.price_capacity OWNER TO postgres;

--
-- Name: last_price_capacity; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.last_price_capacity AS
 WITH flight_date AS (
         SELECT price_capacity_1.flight_id,
            max(price_capacity_1.date) AS date
           FROM public.price_capacity price_capacity_1
          GROUP BY price_capacity_1.flight_id
        )
 SELECT flight.id,
    price_capacity.date,
    price_capacity.price,
    flight.last_price,
    price_capacity.capacity,
    flight.last_capacity,
    price_capacity.channel
   FROM ((public.price_capacity
     JOIN flight_date ON (((price_capacity.flight_id = flight_date.flight_id) AND (price_capacity.date = flight_date.date))))
     JOIN public.flight ON ((price_capacity.flight_id = flight.id)));


ALTER TABLE public.last_price_capacity OWNER TO postgres;

--
-- Name: conflict_price; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.conflict_price AS
 SELECT last_price_capacity.id,
    last_price_capacity.date,
    last_price_capacity.price,
    last_price_capacity.last_price,
    last_price_capacity.capacity,
    last_price_capacity.last_capacity,
    last_price_capacity.channel
   FROM public.last_price_capacity
  WHERE (last_price_capacity.price <> last_price_capacity.last_price);


ALTER TABLE public.conflict_price OWNER TO postgres;

--
-- Name: country; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.country (
    id integer NOT NULL,
    name character varying(100) NOT NULL
);


ALTER TABLE public.country OWNER TO postgres;

--
-- Name: flight_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.flight_history (
    id integer NOT NULL,
    start_date date NOT NULL,
    start_airport_id character varying(3) NOT NULL,
    end_airport_id character varying(3) NOT NULL,
    start_hour time without time zone,
    airline_id character varying(2) NOT NULL,
    flight_number integer
);


ALTER TABLE public.flight_history OWNER TO postgres;

--
-- Name: state; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.state (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    country_id integer
);


ALTER TABLE public.state OWNER TO postgres;

--
-- Name: inter_state_flight_count; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.inter_state_flight_count AS
 SELECT ststate.name AS "Origin State",
    enstate.name AS "Destination State",
    flight.start_date,
    count(*) AS "Number of flight"
   FROM ((((((public.flight
     JOIN public.airport stairport ON (((stairport.id)::text = (flight.start_airport_id)::text)))
     JOIN public.airport enairport ON (((enairport.id)::text = (flight.end_airport_id)::text)))
     JOIN public.city stcity ON ((stcity.id = stairport.city_id)))
     JOIN public.city encity ON ((encity.id = enairport.city_id)))
     JOIN public.state ststate ON ((ststate.id = stcity.state_id)))
     JOIN public.state enstate ON ((enstate.id = encity.state_id)))
  GROUP BY ststate.name, enstate.name, flight.start_date;


ALTER TABLE public.inter_state_flight_count OWNER TO postgres;

--
-- Name: org_airport; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.org_airport AS
 WITH airport_list(id, name, lat, lan, city_id, city_name) AS (
         SELECT airport.id,
            airport.name,
            airport.lat,
            airport.lan,
            airport.city_id,
            city.name AS city_name
           FROM (public.airport
             JOIN public.city ON ((city.id = airport.city_id)))
          WHERE ((airport.id)::text IN ( SELECT DISTINCT flight.start_airport_id
                   FROM public.flight))
        ), city_count AS (
         SELECT airport_list.city_name,
            airport_list.city_id,
            count(*) AS no
           FROM airport_list
          GROUP BY airport_list.city_name, airport_list.city_id
        )
 SELECT airport_list.id,
    airport_list.name,
    airport_list.lat,
    airport_list.lan,
    NULL::integer AS city_id,
    NULL::character varying AS city_name
   FROM (airport_list
     JOIN city_count ON ((city_count.city_id = airport_list.city_id)))
  WHERE (city_count.no = 1)
UNION
 SELECT airport_list.id,
    airport_list.name,
    airport_list.lat,
    airport_list.lan,
    airport_list.city_id,
    airport_list.city_name
   FROM (airport_list
     JOIN city_count ON ((city_count.city_id = airport_list.city_id)))
  WHERE (city_count.no > 1);


ALTER TABLE public.org_airport OWNER TO postgres;

--
-- Name: passenger; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.passenger (
    id integer NOT NULL,
    first_name character varying(100) NOT NULL,
    last_name character varying(100) NOT NULL,
    age integer,
    gender character varying(10),
    CONSTRAINT passenger_age_check CHECK (((age > 0) AND (age < 150))),
    CONSTRAINT passenger_gender_check CHECK (((gender)::text = ANY ((ARRAY['male'::character varying, 'female'::character varying])::text[])))
);


ALTER TABLE public.passenger OWNER TO postgres;

--
-- Name: ticket; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ticket (
    id integer NOT NULL,
    flight_id integer NOT NULL,
    passenger_id integer,
    seat integer NOT NULL,
    price integer NOT NULL,
    CONSTRAINT ticket_price_check CHECK ((price > 0)),
    CONSTRAINT ticket_seat_check CHECK ((seat > 0))
);


ALTER TABLE public.ticket OWNER TO postgres;

--
-- Data for Name: airline; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.airline (id, name) FROM stdin;
\.
COPY public.airline (id, name) FROM '$$PATH$$/2249.dat';

--
-- Data for Name: airport; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.airport (id, name, city_id, lat, lan) FROM stdin;
\.
COPY public.airport (id, name, city_id, lat, lan) FROM '$$PATH$$/2248.dat';

--
-- Data for Name: backup_flight; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.backup_flight (id, start_date, start_airport_id, end_airport_id, start_hour, airline_id, flight_number, last_price, last_capacity, modified) FROM stdin;
\.
COPY public.backup_flight (id, start_date, start_airport_id, end_airport_id, start_hour, airline_id, flight_number, last_price, last_capacity, modified) FROM '$$PATH$$/2254.dat';

--
-- Data for Name: city; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.city (id, name, state_id) FROM stdin;
\.
COPY public.city (id, name, state_id) FROM '$$PATH$$/2247.dat';

--
-- Data for Name: country; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.country (id, name) FROM stdin;
\.
COPY public.country (id, name) FROM '$$PATH$$/2245.dat';

--
-- Data for Name: flight; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.flight (id, start_date, start_airport_id, end_airport_id, start_hour, airline_id, flight_number, last_price, last_capacity) FROM stdin;
\.
COPY public.flight (id, start_date, start_airport_id, end_airport_id, start_hour, airline_id, flight_number, last_price, last_capacity) FROM '$$PATH$$/2250.dat';

--
-- Data for Name: flight_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.flight_history (id, start_date, start_airport_id, end_airport_id, start_hour, airline_id, flight_number) FROM stdin;
\.
COPY public.flight_history (id, start_date, start_airport_id, end_airport_id, start_hour, airline_id, flight_number) FROM '$$PATH$$/2255.dat';

--
-- Data for Name: passenger; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.passenger (id, first_name, last_name, age, gender) FROM stdin;
\.
COPY public.passenger (id, first_name, last_name, age, gender) FROM '$$PATH$$/2252.dat';

--
-- Data for Name: price_capacity; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.price_capacity (flight_id, date, price, capacity, channel) FROM stdin;
\.
COPY public.price_capacity (flight_id, date, price, capacity, channel) FROM '$$PATH$$/2251.dat';

--
-- Data for Name: state; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.state (id, name, country_id) FROM stdin;
\.
COPY public.state (id, name, country_id) FROM '$$PATH$$/2246.dat';

--
-- Data for Name: ticket; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ticket (id, flight_id, passenger_id, seat, price) FROM stdin;
\.
COPY public.ticket (id, flight_id, passenger_id, seat, price) FROM '$$PATH$$/2253.dat';

--
-- Name: airline airline_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.airline
    ADD CONSTRAINT airline_pkey PRIMARY KEY (id);


--
-- Name: airport airport_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.airport
    ADD CONSTRAINT airport_pkey PRIMARY KEY (id);


--
-- Name: backup_flight backup_flight_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.backup_flight
    ADD CONSTRAINT backup_flight_pkey PRIMARY KEY (id, modified);


--
-- Name: city city_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.city
    ADD CONSTRAINT city_pkey PRIMARY KEY (id);


--
-- Name: country country_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.country
    ADD CONSTRAINT country_pkey PRIMARY KEY (id);


--
-- Name: flight_history flight_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flight_history
    ADD CONSTRAINT flight_history_pkey PRIMARY KEY (id);


--
-- Name: flight flight_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flight
    ADD CONSTRAINT flight_pkey PRIMARY KEY (id);


--
-- Name: passenger passenger_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.passenger
    ADD CONSTRAINT passenger_pkey PRIMARY KEY (id);


--
-- Name: price_capacity price_capacity_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.price_capacity
    ADD CONSTRAINT price_capacity_pkey PRIMARY KEY (flight_id, date);


--
-- Name: state state_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.state
    ADD CONSTRAINT state_pkey PRIMARY KEY (id);


--
-- Name: ticket ticket_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket
    ADD CONSTRAINT ticket_pkey PRIMARY KEY (id);


--
-- Name: flight backup_flight_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER backup_flight_trigger BEFORE UPDATE ON public.flight FOR EACH ROW EXECUTE PROCEDURE public.log_last_flight();


--
-- Name: price_capacity update_flight_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_flight_trigger AFTER INSERT ON public.price_capacity FOR EACH ROW EXECUTE PROCEDURE public.update_flight_price();


--
-- Name: airport airport_city_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.airport
    ADD CONSTRAINT airport_city_id_fkey FOREIGN KEY (city_id) REFERENCES public.city(id);


--
-- Name: backup_flight backup_flight_airline_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.backup_flight
    ADD CONSTRAINT backup_flight_airline_id_fkey FOREIGN KEY (airline_id) REFERENCES public.airline(id);


--
-- Name: backup_flight backup_flight_end_airport_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.backup_flight
    ADD CONSTRAINT backup_flight_end_airport_id_fkey FOREIGN KEY (end_airport_id) REFERENCES public.airport(id);


--
-- Name: backup_flight backup_flight_start_airport_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.backup_flight
    ADD CONSTRAINT backup_flight_start_airport_id_fkey FOREIGN KEY (start_airport_id) REFERENCES public.airport(id);


--
-- Name: city city_state_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.city
    ADD CONSTRAINT city_state_id_fkey FOREIGN KEY (state_id) REFERENCES public.state(id);


--
-- Name: flight flight_airline_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flight
    ADD CONSTRAINT flight_airline_id_fkey FOREIGN KEY (airline_id) REFERENCES public.airline(id);


--
-- Name: flight flight_end_airport_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flight
    ADD CONSTRAINT flight_end_airport_id_fkey FOREIGN KEY (end_airport_id) REFERENCES public.airport(id);


--
-- Name: flight_history flight_history_airline_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flight_history
    ADD CONSTRAINT flight_history_airline_id_fkey FOREIGN KEY (airline_id) REFERENCES public.airline(id);


--
-- Name: flight_history flight_history_end_airport_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flight_history
    ADD CONSTRAINT flight_history_end_airport_id_fkey FOREIGN KEY (end_airport_id) REFERENCES public.airport(id);


--
-- Name: flight_history flight_history_start_airport_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flight_history
    ADD CONSTRAINT flight_history_start_airport_id_fkey FOREIGN KEY (start_airport_id) REFERENCES public.airport(id);


--
-- Name: flight flight_start_airport_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flight
    ADD CONSTRAINT flight_start_airport_id_fkey FOREIGN KEY (start_airport_id) REFERENCES public.airport(id);


--
-- Name: price_capacity price_capacity_flight_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.price_capacity
    ADD CONSTRAINT price_capacity_flight_id_fkey FOREIGN KEY (flight_id) REFERENCES public.flight(id);


--
-- Name: state state_country_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.state
    ADD CONSTRAINT state_country_id_fkey FOREIGN KEY (country_id) REFERENCES public.country(id);


--
-- Name: ticket ticket_flight_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket
    ADD CONSTRAINT ticket_flight_id_fkey FOREIGN KEY (flight_id) REFERENCES public.flight(id);


--
-- Name: ticket ticket_passenger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket
    ADD CONSTRAINT ticket_passenger_id_fkey FOREIGN KEY (passenger_id) REFERENCES public.passenger(id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- Name: TABLE backup_flight; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE public.backup_flight FROM PUBLIC;
REVOKE ALL ON TABLE public.backup_flight FROM postgres;
GRANT ALL ON TABLE public.backup_flight TO postgres;
GRANT SELECT ON TABLE public.backup_flight TO operator;


--
-- Name: TABLE flight; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE public.flight FROM PUBLIC;
REVOKE ALL ON TABLE public.flight FROM postgres;
GRANT ALL ON TABLE public.flight TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.flight TO operator;


--
-- Name: TABLE price_capacity; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE public.price_capacity FROM PUBLIC;
REVOKE ALL ON TABLE public.price_capacity FROM postgres;
GRANT ALL ON TABLE public.price_capacity TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.price_capacity TO operator;


--
-- Name: TABLE last_price_capacity; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE public.last_price_capacity FROM PUBLIC;
REVOKE ALL ON TABLE public.last_price_capacity FROM postgres;
GRANT ALL ON TABLE public.last_price_capacity TO postgres;
GRANT SELECT ON TABLE public.last_price_capacity TO operator;


--
-- Name: TABLE conflict_price; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE public.conflict_price FROM PUBLIC;
REVOKE ALL ON TABLE public.conflict_price FROM postgres;
GRANT ALL ON TABLE public.conflict_price TO postgres;
GRANT SELECT ON TABLE public.conflict_price TO operator;


--
-- Name: TABLE flight_history; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE public.flight_history FROM PUBLIC;
REVOKE ALL ON TABLE public.flight_history FROM postgres;
GRANT ALL ON TABLE public.flight_history TO postgres;
GRANT SELECT ON TABLE public.flight_history TO operator;


--
-- Name: TABLE inter_state_flight_count; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE public.inter_state_flight_count FROM PUBLIC;
REVOKE ALL ON TABLE public.inter_state_flight_count FROM postgres;
GRANT ALL ON TABLE public.inter_state_flight_count TO postgres;
GRANT SELECT ON TABLE public.inter_state_flight_count TO operator;


--
-- Name: TABLE org_airport; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE public.org_airport FROM PUBLIC;
REVOKE ALL ON TABLE public.org_airport FROM postgres;
GRANT ALL ON TABLE public.org_airport TO postgres;
GRANT SELECT ON TABLE public.org_airport TO operator;


--
-- Name: TABLE passenger; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE public.passenger FROM PUBLIC;
REVOKE ALL ON TABLE public.passenger FROM postgres;
GRANT ALL ON TABLE public.passenger TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.passenger TO operator;


--
-- Name: TABLE ticket; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE public.ticket FROM PUBLIC;
REVOKE ALL ON TABLE public.ticket FROM postgres;
GRANT ALL ON TABLE public.ticket TO postgres;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ticket TO operator;


--
-- PostgreSQL database dump complete
--

